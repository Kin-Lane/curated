require "uri"

class CuratedApi
  basePath = "https://curated.api.kinlane.com/"
  # apiInvoker = APIInvoker

  # retrieves all curated items
  # retrieves all curated items
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param query a text query to search across curated items
  # @param [Hash] opts the optional parameters
  # @return array[curated]
  def self.get_curated(appid, appkey, query, opts = {})
    # verify existence of params
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "query is required" if query.nil?

    # resource path
    path = "/curated/".sub('{format}','json')

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey
    query_params[:'query'] = query

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| curated.new(response) }
  end

  # add curated
  # add curated
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param title title of the curated item
  # @param link url for the curated item
  # @param item_date date applied to the curated item
  # @param details raw details of the curated item
  # @param status status of the curated item
  # @param public_comment public comment on the curated item
  # @param original_date original date of the curated item
  # @param author author of the curated item
  # @param processed has the curated item been processed
  # @param domain domain of the curated item
  # @param screenshot_url screenshot url for the curated item
  # @param resolved_url resolved url for the item
  # @param weekly_summary is curated item included in weekly summary
  # @param weekly_roundup is curated included in weekly roundup
  # @param [Hash] opts the optional parameters
  # @return array[curated]
  def self.add_curated(appid, appkey, title, link, item_date, details, status, public_comment, original_date, author, processed, domain, screenshot_url, resolved_url, weekly_summary, weekly_roundup, opts = {})
    # verify existence of params
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "title is required" if title.nil?
    raise "link is required" if link.nil?
    raise "item_date is required" if item_date.nil?
    raise "details is required" if details.nil?
    raise "status is required" if status.nil?
    raise "public_comment is required" if public_comment.nil?
    raise "original_date is required" if original_date.nil?
    raise "author is required" if author.nil?
    raise "processed is required" if processed.nil?
    raise "domain is required" if domain.nil?
    raise "screenshot_url is required" if screenshot_url.nil?
    raise "resolved_url is required" if resolved_url.nil?
    raise "weekly_summary is required" if weekly_summary.nil?
    raise "weekly_roundup is required" if weekly_roundup.nil?

    # resource path
    path = "/curated/".sub('{format}','json')

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey
    query_params[:'title'] = title
    query_params[:'link'] = link
    query_params[:'item_date'] = item_date
    query_params[:'details'] = details
    query_params[:'status'] = status
    query_params[:'public_comment'] = public_comment
    query_params[:'original_date'] = original_date
    query_params[:'author'] = author
    query_params[:'processed'] = processed
    query_params[:'domain'] = domain
    query_params[:'screenshot_url'] = screenshot_url
    query_params[:'resolved_url'] = resolved_url
    query_params[:'weekly_summary'] = weekly_summary
    query_params[:'weekly_roundup'] = weekly_roundup

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:POST, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| curated.new(response) }
  end

  # retrieve a curated item
  # retrieve a curated item
  # @param curated_id id for the curated id
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param [Hash] opts the optional parameters
  # @return array[curated]
  def self.get_curated_1(curated_id, appid, appkey, opts = {})
    # verify existence of params
    raise "curated_id is required" if curated_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/curated/{curated_id}".sub('{format}','json').sub('{' + 'curated_id' + '}', curated_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| curated.new(response) }
  end

  # updatea a curated item
  # updatea a curated item
  # @param curated_id id of the curated item
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param title title of the curated item
  # @param link url for the curated item
  # @param item_date date applied to the curated item
  # @param details raw details of the curated item
  # @param status status of the curated item
  # @param public_comment public comment on the curated item
  # @param original_date original date of the curated item
  # @param author author of the curated item
  # @param processed has the curated item been processed
  # @param domain domain of the curated item
  # @param screenshot_url screenshot url for the curated item
  # @param resolved_url resolved url for the item
  # @param weekly_summary is curated item included in weekly summary
  # @param weekly_roundup is curated included in weekly roundup
  # @param [Hash] opts the optional parameters
  # @return array[curated]
  def self.update_curated(curated_id, appid, appkey, title, link, item_date, details, status, public_comment, original_date, author, processed, domain, screenshot_url, resolved_url, weekly_summary, weekly_roundup, opts = {})
    # verify existence of params
    raise "curated_id is required" if curated_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "title is required" if title.nil?
    raise "link is required" if link.nil?
    raise "item_date is required" if item_date.nil?
    raise "details is required" if details.nil?
    raise "status is required" if status.nil?
    raise "public_comment is required" if public_comment.nil?
    raise "original_date is required" if original_date.nil?
    raise "author is required" if author.nil?
    raise "processed is required" if processed.nil?
    raise "domain is required" if domain.nil?
    raise "screenshot_url is required" if screenshot_url.nil?
    raise "resolved_url is required" if resolved_url.nil?
    raise "weekly_summary is required" if weekly_summary.nil?
    raise "weekly_roundup is required" if weekly_roundup.nil?

    # resource path
    path = "/curated/{curated_id}".sub('{format}','json').sub('{' + 'curated_id' + '}', curated_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey
    query_params[:'title'] = title
    query_params[:'link'] = link
    query_params[:'item_date'] = item_date
    query_params[:'details'] = details
    query_params[:'status'] = status
    query_params[:'public_comment'] = public_comment
    query_params[:'original_date'] = original_date
    query_params[:'author'] = author
    query_params[:'processed'] = processed
    query_params[:'domain'] = domain
    query_params[:'screenshot_url'] = screenshot_url
    query_params[:'resolved_url'] = resolved_url
    query_params[:'weekly_summary'] = weekly_summary
    query_params[:'weekly_roundup'] = weekly_roundup

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:PUT, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| curated.new(response) }
  end

  # delete a curated item
  # delete a curated item
  # @param curated_id id for the curated item
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param [Hash] opts the optional parameters
  # @return array[curated]
  def self.delete_curated(curated_id, appid, appkey, opts = {})
    # verify existence of params
    raise "curated_id is required" if curated_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/curated/{curated_id}".sub('{format}','json').sub('{' + 'curated_id' + '}', curated_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:DELETE, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| curated.new(response) }
  end
end
