require "uri"

class TagsApi
  basePath = "https://curated.api.kinlane.com/"
  # apiInvoker = APIInvoker

  # retrieves all tags for curated
  # retrieves all tags for curated
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param query a text query to search across curated items
  # @param [Hash] opts the optional parameters
  # @return array[curated]
  def self.get_curated_tags(appid, appkey, query, opts = {})
    # verify existence of params
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "query is required" if query.nil?

    # resource path
    path = "/curated/tags/".sub('{format}','json')

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey
    query_params[:'query'] = query

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| curated.new(response) }
  end

  # curated tags by week
  # curated tags by week
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param week the week to retrieve tags by
  # @param [Hash] opts the optional parameters
  # @return array[curated]
  def self.get_curated_tags_by_week(appid, appkey, week, opts = {})
    # verify existence of params
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "week is required" if week.nil?

    # resource path
    path = "/curated/tags/byweek/".sub('{format}','json')

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey
    query_params[:'week'] = week

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| curated.new(response) }
  end

  # curated by tag and week
  # curated by tag and week
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param tag the tag to filter by
  # @param week the week to filter by, defaults to this week
  # @param [Hash] opts the optional parameters
  # @return array[curated]
  def self.get_curated_tag_curated(appid, appkey, tag, week, opts = {})
    # verify existence of params
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "tag is required" if tag.nil?
    raise "week is required" if week.nil?

    # resource path
    path = "/curated/tags/byweek/{tag}/curated/".sub('{format}','json').sub('{' + 'tag' + '}', tag.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey
    query_params[:'week'] = week

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| curated.new(response) }
  end

  # delete curated tag
  # delete curated tag
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param tag Tag to be removed
  # @param [Hash] opts the optional parameters
  # @return array[curated]
  def self.delete_curated_tag(appid, appkey, tag, opts = {})
    # verify existence of params
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "tag is required" if tag.nil?

    # resource path
    path = "/curated/tags/{tag}".sub('{format}','json').sub('{' + 'tag' + '}', tag.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:DELETE, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| curated.new(response) }
  end

  # get curated tags
  # get curated tags
  # @param curated_id id for curated item
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param [Hash] opts the optional parameters
  # @return array[tag]
  def self.get_curated_tags_1(curated_id, appid, appkey, opts = {})
    # verify existence of params
    raise "curated_id is required" if curated_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/curated/{curated_id}/tags/".sub('{format}','json').sub('{' + 'curated_id' + '}', curated_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| tag.new(response) }
  end

  # add curated tag
  # add curated tag
  # @param curated_id id for curated item
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param tag tag name
  # @param [Hash] opts the optional parameters
  # @return array[tag]
  def self.add_curated_tag(curated_id, appid, appkey, tag, opts = {})
    # verify existence of params
    raise "curated_id is required" if curated_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "tag is required" if tag.nil?

    # resource path
    path = "/curated/{curated_id}/tags/".sub('{format}','json').sub('{' + 'curated_id' + '}', curated_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey
    query_params[:'tag'] = tag

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:POST, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| tag.new(response) }
  end

  # delete a curated item
  # delete a curated item
  # @param curated_id id for the curated item
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param tag tag to upate on the curated item
  # @param [Hash] opts the optional parameters
  # @return array[tag]
  def self.delete_curated(curated_id, appid, appkey, tag, opts = {})
    # verify existence of params
    raise "curated_id is required" if curated_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "tag is required" if tag.nil?

    # resource path
    path = "/curated/{curated_id}/tags/{tag}".sub('{format}','json').sub('{' + 'curated_id' + '}', curated_id.to_s).sub('{' + 'tag' + '}', tag.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:DELETE, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| tag.new(response) }
  end
end
