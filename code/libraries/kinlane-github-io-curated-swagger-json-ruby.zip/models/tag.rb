
class Tag
  attr_accessor :tag, :curated_count
  # :internal => :external
  def self.attribute_map
    {
      :tag => :'tag',
      :curated_count => :'curated_count'
      
    }
  end

  def initialize(attributes = {})
    return if attributes.empty?
    # Morph attribute keys into undescored rubyish style
    
    if self.class.attribute_map[:"tag"]
      @tag = attributes["tag"]
    end
    
    if self.class.attribute_map[:"curated_count"]
      @curated_count = attributes["curated_count"]
    end
    
  end

  def to_body
    body = {}
    self.class.attribute_map.each_pair do |key, value|
      body[value] = self.send(key) unless self.send(key).nil?
    end
    body
  end
end
