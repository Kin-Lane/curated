#!/usr/bin/env python
"""Add all of the modules in the current directory to __all__"""
import os

# import models into package

from .models.curated import Curated

from .models.tag import Tag

from .models.note import Note


# import apis into package

from .notes_api import NotesApi

from .curated_by_week_api import CuratedByWeekApi

from .tags_api import TagsApi

from .curated_api import CuratedApi


# import ApiClient
from .swagger import ApiClient

__all__ = []

for module in os.listdir(os.path.dirname(__file__)):
  if module != '__init__.py' and module[-3:] == '.py':
    __all__.append(module[:-3])
