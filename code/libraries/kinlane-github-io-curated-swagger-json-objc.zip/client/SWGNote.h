#import <Foundation/Foundation.h>
#import "SWGObject.h"


@protocol SWGNote
@end
  
@interface SWGNote : SWGObject

/* type of note [optional]
 */
@property(nonatomic) NSString* type;
/* text of note [optional]
 */
@property(nonatomic) NSString* note;

@end
