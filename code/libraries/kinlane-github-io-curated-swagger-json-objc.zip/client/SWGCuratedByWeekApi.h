#import <Foundation/Foundation.h>
#import "SWGCurated.h"
#import "SWGObject.h"


@interface SWGCuratedByWeekApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGCuratedByWeekApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 curated items by week
 curated items by week

 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param week the week number
 

 return type: NSArray<SWGCurated>*
 */
-(NSNumber*) getCuratedByWeekWithCompletionBlock :(NSString*) appid 
     appkey:(NSString*) appkey 
     week:(NSNumber*) week 
    
    completionHandler: (void (^)(NSArray<SWGCurated>* output, NSError* error))completionBlock;
    


/**

 curated items by week archived
 curated items by week archived

 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param week the week number
 

 return type: NSArray<SWGCurated>*
 */
-(NSNumber*) getCuratedByWeekPublishedWithCompletionBlock :(NSString*) appid 
     appkey:(NSString*) appkey 
     week:(NSNumber*) week 
    
    completionHandler: (void (^)(NSArray<SWGCurated>* output, NSError* error))completionBlock;
    


/**

 curated items by week published
 curated items by week published

 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param week the week number
 

 return type: NSArray<SWGCurated>*
 */
-(NSNumber*) getCuratedByWeekPublished_1WithCompletionBlock :(NSString*) appid 
     appkey:(NSString*) appkey 
     week:(NSNumber*) week 
    
    completionHandler: (void (^)(NSArray<SWGCurated>* output, NSError* error))completionBlock;
    


/**

 curated item by week for review
 curated item by week for review

 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param week the week number
 

 return type: NSArray<SWGCurated>*
 */
-(NSNumber*) getCuratedByWeekReviewWithCompletionBlock :(NSString*) appid 
     appkey:(NSString*) appkey 
     week:(NSNumber*) week 
    
    completionHandler: (void (^)(NSArray<SWGCurated>* output, NSError* error))completionBlock;
    



@end