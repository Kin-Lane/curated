#import "SWGCuratedApi.h"
#import "SWGFile.h"
#import "SWGQueryParamCollection.h"
#import "SWGApiClient.h"
#import "SWGCurated.h"


@interface SWGCuratedApi ()
    @property (readwrite, nonatomic, strong) NSMutableDictionary *defaultHeaders;
@end

@implementation SWGCuratedApi
static NSString * basePath = @"https://curated.api.kinlane.com/";

+(SWGCuratedApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key {
    static SWGCuratedApi* singletonAPI = nil;

    if (singletonAPI == nil) {
        singletonAPI = [[SWGCuratedApi alloc] init];
        [singletonAPI addHeader:headerValue forKey:key];
    }
    return singletonAPI;
}

+(void) setBasePath:(NSString*)path {
    basePath = path;
}

+(NSString*) getBasePath {
    return basePath;
}

-(SWGApiClient*) apiClient {
    return [SWGApiClient sharedClientFromPool:basePath];
}

-(void) addHeader:(NSString*)value forKey:(NSString*)key {
    [self.defaultHeaders setValue:value forKey:key];
}

-(id) init {
    self = [super init];
    self.defaultHeaders = [NSMutableDictionary dictionary];
    [self apiClient];
    return self;
}

-(void) setHeaderValue:(NSString*) value
           forKey:(NSString*)key {
    [self.defaultHeaders setValue:value forKey:key];
}

-(unsigned long) requestQueueSize {
    return [SWGApiClient requestQueueSize];
}


-(NSNumber*) getCuratedWithCompletionBlock: (NSString*) appid
         appkey: (NSString*) appkey
         query: (NSString*) query
        
        completionHandler: (void (^)(NSArray<SWGCurated>* output, NSError* error))completionBlock
         {

    NSMutableString* requestUrl = [NSMutableString stringWithFormat:@"%@/curated/", basePath];

    // remove format in URL if needed
    if ([requestUrl rangeOfString:@".{format}"].location != NSNotFound)
        [requestUrl replaceCharactersInRange: [requestUrl rangeOfString:@".{format}"] withString:@".json"];

    

    NSArray* requestContentTypes = @[];
    NSString* requestContentType = [requestContentTypes count] > 0 ? requestContentTypes[0] : @"application/json";

    NSArray* responseContentTypes = @[];
    NSString* responseContentType = [responseContentTypes count] > 0 ? responseContentTypes[0] : @"application/json";

    NSMutableDictionary* queryParams = [[NSMutableDictionary alloc] init];
    if(appid != nil) {
        
        queryParams[@"appid"] = appid;
    }
    if(appkey != nil) {
        
        queryParams[@"appkey"] = appkey;
    }
    if(query != nil) {
        
        queryParams[@"query"] = query;
    }
    
    NSMutableDictionary* headerParams = [NSMutableDictionary dictionaryWithDictionary:self.defaultHeaders];

    

    id bodyDictionary = nil;
    
    

    NSMutableDictionary * formParams = [[NSMutableDictionary alloc]init];

    
    

    

    SWGApiClient* client = [SWGApiClient sharedClientFromPool:basePath];

    
    // response is in a container
        // array container response type
    return [client dictionary: requestUrl 
                       method: @"GET" 
                  queryParams: queryParams 
                         body: bodyDictionary 
                 headerParams: headerParams
           requestContentType: requestContentType
          responseContentType: responseContentType
              completionBlock: ^(NSDictionary *data, NSError *error) {
                if (error) {
                    completionBlock(nil, error);
                    return;
                }
                
                if([data isKindOfClass:[NSArray class]]){
                    NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[data count]];
                    for (NSDictionary* dict in (NSArray*)data) {
                        
                        
                        SWGCurated* d = [[SWGCurated alloc] initWithDictionary:dict error:nil];
                        
                        [objs addObject:d];
                    }
                    completionBlock((NSArray<SWGCurated>*)objs, nil);
                }
                
                
            }];
    

    

    
}

-(NSNumber*) addCuratedWithCompletionBlock: (NSString*) appid
         appkey: (NSString*) appkey
         title: (NSString*) title
         link: (NSString*) link
         item_date: (NSString*) item_date
         details: (NSString*) details
         status: (NSString*) status
         public_comment: (NSString*) public_comment
         original_date: (NSString*) original_date
         author: (NSString*) author
         processed: (NSString*) processed
         domain: (NSString*) domain
         screenshot_url: (NSString*) screenshot_url
         resolved_url: (NSString*) resolved_url
         weekly_summary: (NSString*) weekly_summary
         weekly_roundup: (NSString*) weekly_roundup
        
        completionHandler: (void (^)(NSArray<SWGCurated>* output, NSError* error))completionBlock
         {

    NSMutableString* requestUrl = [NSMutableString stringWithFormat:@"%@/curated/", basePath];

    // remove format in URL if needed
    if ([requestUrl rangeOfString:@".{format}"].location != NSNotFound)
        [requestUrl replaceCharactersInRange: [requestUrl rangeOfString:@".{format}"] withString:@".json"];

    

    NSArray* requestContentTypes = @[];
    NSString* requestContentType = [requestContentTypes count] > 0 ? requestContentTypes[0] : @"application/json";

    NSArray* responseContentTypes = @[];
    NSString* responseContentType = [responseContentTypes count] > 0 ? responseContentTypes[0] : @"application/json";

    NSMutableDictionary* queryParams = [[NSMutableDictionary alloc] init];
    if(appid != nil) {
        
        queryParams[@"appid"] = appid;
    }
    if(appkey != nil) {
        
        queryParams[@"appkey"] = appkey;
    }
    if(title != nil) {
        
        queryParams[@"title"] = title;
    }
    if(link != nil) {
        
        queryParams[@"link"] = link;
    }
    if(item_date != nil) {
        
        queryParams[@"item_date"] = item_date;
    }
    if(details != nil) {
        
        queryParams[@"details"] = details;
    }
    if(status != nil) {
        
        queryParams[@"status"] = status;
    }
    if(public_comment != nil) {
        
        queryParams[@"public_comment"] = public_comment;
    }
    if(original_date != nil) {
        
        queryParams[@"original_date"] = original_date;
    }
    if(author != nil) {
        
        queryParams[@"author"] = author;
    }
    if(processed != nil) {
        
        queryParams[@"processed"] = processed;
    }
    if(domain != nil) {
        
        queryParams[@"domain"] = domain;
    }
    if(screenshot_url != nil) {
        
        queryParams[@"screenshot_url"] = screenshot_url;
    }
    if(resolved_url != nil) {
        
        queryParams[@"resolved_url"] = resolved_url;
    }
    if(weekly_summary != nil) {
        
        queryParams[@"weekly_summary"] = weekly_summary;
    }
    if(weekly_roundup != nil) {
        
        queryParams[@"weekly_roundup"] = weekly_roundup;
    }
    
    NSMutableDictionary* headerParams = [NSMutableDictionary dictionaryWithDictionary:self.defaultHeaders];

    

    id bodyDictionary = nil;
    
    

    NSMutableDictionary * formParams = [[NSMutableDictionary alloc]init];

    
    

    

    SWGApiClient* client = [SWGApiClient sharedClientFromPool:basePath];

    
    // response is in a container
        // array container response type
    return [client dictionary: requestUrl 
                       method: @"POST" 
                  queryParams: queryParams 
                         body: bodyDictionary 
                 headerParams: headerParams
           requestContentType: requestContentType
          responseContentType: responseContentType
              completionBlock: ^(NSDictionary *data, NSError *error) {
                if (error) {
                    completionBlock(nil, error);
                    return;
                }
                
                if([data isKindOfClass:[NSArray class]]){
                    NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[data count]];
                    for (NSDictionary* dict in (NSArray*)data) {
                        
                        
                        SWGCurated* d = [[SWGCurated alloc] initWithDictionary:dict error:nil];
                        
                        [objs addObject:d];
                    }
                    completionBlock((NSArray<SWGCurated>*)objs, nil);
                }
                
                
            }];
    

    

    
}

-(NSNumber*) getCurated_1WithCompletionBlock: (NSString*) curated_id
         appid: (NSString*) appid
         appkey: (NSString*) appkey
        
        completionHandler: (void (^)(NSArray<SWGCurated>* output, NSError* error))completionBlock
         {

    NSMutableString* requestUrl = [NSMutableString stringWithFormat:@"%@/curated/{curated_id}", basePath];

    // remove format in URL if needed
    if ([requestUrl rangeOfString:@".{format}"].location != NSNotFound)
        [requestUrl replaceCharactersInRange: [requestUrl rangeOfString:@".{format}"] withString:@".json"];

    [requestUrl replaceCharactersInRange: [requestUrl rangeOfString:[NSString stringWithFormat:@"%@%@%@", @"{", @"curated_id", @"}"]] withString: [SWGApiClient escape:curated_id]];
    

    NSArray* requestContentTypes = @[];
    NSString* requestContentType = [requestContentTypes count] > 0 ? requestContentTypes[0] : @"application/json";

    NSArray* responseContentTypes = @[];
    NSString* responseContentType = [responseContentTypes count] > 0 ? responseContentTypes[0] : @"application/json";

    NSMutableDictionary* queryParams = [[NSMutableDictionary alloc] init];
    if(appid != nil) {
        
        queryParams[@"appid"] = appid;
    }
    if(appkey != nil) {
        
        queryParams[@"appkey"] = appkey;
    }
    
    NSMutableDictionary* headerParams = [NSMutableDictionary dictionaryWithDictionary:self.defaultHeaders];

    

    id bodyDictionary = nil;
    
    

    NSMutableDictionary * formParams = [[NSMutableDictionary alloc]init];

    
    

    

    SWGApiClient* client = [SWGApiClient sharedClientFromPool:basePath];

    
    // response is in a container
        // array container response type
    return [client dictionary: requestUrl 
                       method: @"GET" 
                  queryParams: queryParams 
                         body: bodyDictionary 
                 headerParams: headerParams
           requestContentType: requestContentType
          responseContentType: responseContentType
              completionBlock: ^(NSDictionary *data, NSError *error) {
                if (error) {
                    completionBlock(nil, error);
                    return;
                }
                
                if([data isKindOfClass:[NSArray class]]){
                    NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[data count]];
                    for (NSDictionary* dict in (NSArray*)data) {
                        
                        
                        SWGCurated* d = [[SWGCurated alloc] initWithDictionary:dict error:nil];
                        
                        [objs addObject:d];
                    }
                    completionBlock((NSArray<SWGCurated>*)objs, nil);
                }
                
                
            }];
    

    

    
}

-(NSNumber*) updateCuratedWithCompletionBlock: (NSNumber*) curated_id
         appid: (NSString*) appid
         appkey: (NSString*) appkey
         title: (NSString*) title
         link: (NSString*) link
         item_date: (NSString*) item_date
         details: (NSString*) details
         status: (NSString*) status
         public_comment: (NSString*) public_comment
         original_date: (NSString*) original_date
         author: (NSString*) author
         processed: (NSString*) processed
         domain: (NSString*) domain
         screenshot_url: (NSString*) screenshot_url
         resolved_url: (NSString*) resolved_url
         weekly_summary: (NSString*) weekly_summary
         weekly_roundup: (NSString*) weekly_roundup
        
        completionHandler: (void (^)(NSArray<SWGCurated>* output, NSError* error))completionBlock
         {

    NSMutableString* requestUrl = [NSMutableString stringWithFormat:@"%@/curated/{curated_id}", basePath];

    // remove format in URL if needed
    if ([requestUrl rangeOfString:@".{format}"].location != NSNotFound)
        [requestUrl replaceCharactersInRange: [requestUrl rangeOfString:@".{format}"] withString:@".json"];

    [requestUrl replaceCharactersInRange: [requestUrl rangeOfString:[NSString stringWithFormat:@"%@%@%@", @"{", @"curated_id", @"}"]] withString: [SWGApiClient escape:curated_id]];
    

    NSArray* requestContentTypes = @[];
    NSString* requestContentType = [requestContentTypes count] > 0 ? requestContentTypes[0] : @"application/json";

    NSArray* responseContentTypes = @[];
    NSString* responseContentType = [responseContentTypes count] > 0 ? responseContentTypes[0] : @"application/json";

    NSMutableDictionary* queryParams = [[NSMutableDictionary alloc] init];
    if(appid != nil) {
        
        queryParams[@"appid"] = appid;
    }
    if(appkey != nil) {
        
        queryParams[@"appkey"] = appkey;
    }
    if(title != nil) {
        
        queryParams[@"title"] = title;
    }
    if(link != nil) {
        
        queryParams[@"link"] = link;
    }
    if(item_date != nil) {
        
        queryParams[@"item_date"] = item_date;
    }
    if(details != nil) {
        
        queryParams[@"details"] = details;
    }
    if(status != nil) {
        
        queryParams[@"status"] = status;
    }
    if(public_comment != nil) {
        
        queryParams[@"public_comment"] = public_comment;
    }
    if(original_date != nil) {
        
        queryParams[@"original_date"] = original_date;
    }
    if(author != nil) {
        
        queryParams[@"author"] = author;
    }
    if(processed != nil) {
        
        queryParams[@"processed"] = processed;
    }
    if(domain != nil) {
        
        queryParams[@"domain"] = domain;
    }
    if(screenshot_url != nil) {
        
        queryParams[@"screenshot_url"] = screenshot_url;
    }
    if(resolved_url != nil) {
        
        queryParams[@"resolved_url"] = resolved_url;
    }
    if(weekly_summary != nil) {
        
        queryParams[@"weekly_summary"] = weekly_summary;
    }
    if(weekly_roundup != nil) {
        
        queryParams[@"weekly_roundup"] = weekly_roundup;
    }
    
    NSMutableDictionary* headerParams = [NSMutableDictionary dictionaryWithDictionary:self.defaultHeaders];

    

    id bodyDictionary = nil;
    
    

    NSMutableDictionary * formParams = [[NSMutableDictionary alloc]init];

    
    

    

    SWGApiClient* client = [SWGApiClient sharedClientFromPool:basePath];

    
    // response is in a container
        // array container response type
    return [client dictionary: requestUrl 
                       method: @"PUT" 
                  queryParams: queryParams 
                         body: bodyDictionary 
                 headerParams: headerParams
           requestContentType: requestContentType
          responseContentType: responseContentType
              completionBlock: ^(NSDictionary *data, NSError *error) {
                if (error) {
                    completionBlock(nil, error);
                    return;
                }
                
                if([data isKindOfClass:[NSArray class]]){
                    NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[data count]];
                    for (NSDictionary* dict in (NSArray*)data) {
                        
                        
                        SWGCurated* d = [[SWGCurated alloc] initWithDictionary:dict error:nil];
                        
                        [objs addObject:d];
                    }
                    completionBlock((NSArray<SWGCurated>*)objs, nil);
                }
                
                
            }];
    

    

    
}

-(NSNumber*) deleteCuratedWithCompletionBlock: (NSString*) curated_id
         appid: (NSString*) appid
         appkey: (NSString*) appkey
        
        completionHandler: (void (^)(NSArray<SWGCurated>* output, NSError* error))completionBlock
         {

    NSMutableString* requestUrl = [NSMutableString stringWithFormat:@"%@/curated/{curated_id}", basePath];

    // remove format in URL if needed
    if ([requestUrl rangeOfString:@".{format}"].location != NSNotFound)
        [requestUrl replaceCharactersInRange: [requestUrl rangeOfString:@".{format}"] withString:@".json"];

    [requestUrl replaceCharactersInRange: [requestUrl rangeOfString:[NSString stringWithFormat:@"%@%@%@", @"{", @"curated_id", @"}"]] withString: [SWGApiClient escape:curated_id]];
    

    NSArray* requestContentTypes = @[];
    NSString* requestContentType = [requestContentTypes count] > 0 ? requestContentTypes[0] : @"application/json";

    NSArray* responseContentTypes = @[];
    NSString* responseContentType = [responseContentTypes count] > 0 ? responseContentTypes[0] : @"application/json";

    NSMutableDictionary* queryParams = [[NSMutableDictionary alloc] init];
    if(appid != nil) {
        
        queryParams[@"appid"] = appid;
    }
    if(appkey != nil) {
        
        queryParams[@"appkey"] = appkey;
    }
    
    NSMutableDictionary* headerParams = [NSMutableDictionary dictionaryWithDictionary:self.defaultHeaders];

    

    id bodyDictionary = nil;
    
    

    NSMutableDictionary * formParams = [[NSMutableDictionary alloc]init];

    
    

    

    SWGApiClient* client = [SWGApiClient sharedClientFromPool:basePath];

    
    // response is in a container
        // array container response type
    return [client dictionary: requestUrl 
                       method: @"DELETE" 
                  queryParams: queryParams 
                         body: bodyDictionary 
                 headerParams: headerParams
           requestContentType: requestContentType
          responseContentType: responseContentType
              completionBlock: ^(NSDictionary *data, NSError *error) {
                if (error) {
                    completionBlock(nil, error);
                    return;
                }
                
                if([data isKindOfClass:[NSArray class]]){
                    NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[data count]];
                    for (NSDictionary* dict in (NSArray*)data) {
                        
                        
                        SWGCurated* d = [[SWGCurated alloc] initWithDictionary:dict error:nil];
                        
                        [objs addObject:d];
                    }
                    completionBlock((NSArray<SWGCurated>*)objs, nil);
                }
                
                
            }];
    

    

    
}



@end
