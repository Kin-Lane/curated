#import <Foundation/Foundation.h>
#import "SWGCurated.h"
#import "SWGTag.h"
#import "SWGObject.h"


@interface SWGTagsApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGTagsApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 retrieves all tags for curated
 retrieves all tags for curated

 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param query a text query to search across curated items
 

 return type: NSArray<SWGCurated>*
 */
-(NSNumber*) getCuratedTagsWithCompletionBlock :(NSString*) appid 
     appkey:(NSString*) appkey 
     query:(NSString*) query 
    
    completionHandler: (void (^)(NSArray<SWGCurated>* output, NSError* error))completionBlock;
    


/**

 curated tags by week
 curated tags by week

 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param week the week to retrieve tags by
 

 return type: NSArray<SWGCurated>*
 */
-(NSNumber*) getCuratedTagsByWeekWithCompletionBlock :(NSString*) appid 
     appkey:(NSString*) appkey 
     week:(NSString*) week 
    
    completionHandler: (void (^)(NSArray<SWGCurated>* output, NSError* error))completionBlock;
    


/**

 curated by tag and week
 curated by tag and week

 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param tag the tag to filter by
 @param week the week to filter by, defaults to this week
 

 return type: NSArray<SWGCurated>*
 */
-(NSNumber*) getCuratedTagCuratedWithCompletionBlock :(NSString*) appid 
     appkey:(NSString*) appkey 
     tag:(NSString*) tag 
     week:(NSString*) week 
    
    completionHandler: (void (^)(NSArray<SWGCurated>* output, NSError* error))completionBlock;
    


/**

 delete curated tag
 delete curated tag

 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param tag Tag to be removed
 

 return type: NSArray<SWGCurated>*
 */
-(NSNumber*) deleteCuratedTagWithCompletionBlock :(NSString*) appid 
     appkey:(NSString*) appkey 
     tag:(NSString*) tag 
    
    completionHandler: (void (^)(NSArray<SWGCurated>* output, NSError* error))completionBlock;
    


/**

 get curated tags
 get curated tags

 @param curated_id id for curated item
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 

 return type: NSArray<SWGTag>*
 */
-(NSNumber*) getCuratedTags_1WithCompletionBlock :(NSString*) curated_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGTag>* output, NSError* error))completionBlock;
    


/**

 add curated tag
 add curated tag

 @param curated_id id for curated item
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param tag tag name
 

 return type: NSArray<SWGTag>*
 */
-(NSNumber*) addCuratedTagWithCompletionBlock :(NSString*) curated_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     tag:(NSString*) tag 
    
    completionHandler: (void (^)(NSArray<SWGTag>* output, NSError* error))completionBlock;
    


/**

 delete a curated item
 delete a curated item

 @param curated_id id for the curated item
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param tag tag to upate on the curated item
 

 return type: NSArray<SWGTag>*
 */
-(NSNumber*) deleteCuratedWithCompletionBlock :(NSString*) curated_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     tag:(NSString*) tag 
    
    completionHandler: (void (^)(NSArray<SWGTag>* output, NSError* error))completionBlock;
    



@end