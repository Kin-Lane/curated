#import <Foundation/Foundation.h>
#import "SWGObject.h"


@protocol SWGTag
@end
  
@interface SWGTag : SWGObject

/* text tag [optional]
 */
@property(nonatomic) NSString* tag;
/* number of items curated with tag [optional]
 */
@property(nonatomic) NSNumber* curated_count;

@end
