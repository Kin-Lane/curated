#import <Foundation/Foundation.h>
#import "SWGObject.h"


@protocol SWGCurated
@end
  
@interface SWGCurated : SWGObject

/* title of the curated item [optional]
 */
@property(nonatomic) NSString* title;
/* url for the curated item [optional]
 */
@property(nonatomic) NSString* link;
/* date applied to the curated item [optional]
 */
@property(nonatomic) NSString* item_date;

@end
