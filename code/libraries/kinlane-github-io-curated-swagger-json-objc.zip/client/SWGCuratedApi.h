#import <Foundation/Foundation.h>
#import "SWGCurated.h"
#import "SWGObject.h"


@interface SWGCuratedApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGCuratedApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 retrieves all curated items
 retrieves all curated items

 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param query a text query to search across curated items
 

 return type: NSArray<SWGCurated>*
 */
-(NSNumber*) getCuratedWithCompletionBlock :(NSString*) appid 
     appkey:(NSString*) appkey 
     query:(NSString*) query 
    
    completionHandler: (void (^)(NSArray<SWGCurated>* output, NSError* error))completionBlock;
    


/**

 add curated
 add curated

 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param title title of the curated item
 @param link url for the curated item
 @param item_date date applied to the curated item
 @param details raw details of the curated item
 @param status status of the curated item
 @param public_comment public comment on the curated item
 @param original_date original date of the curated item
 @param author author of the curated item
 @param processed has the curated item been processed
 @param domain domain of the curated item
 @param screenshot_url screenshot url for the curated item
 @param resolved_url resolved url for the item
 @param weekly_summary is curated item included in weekly summary
 @param weekly_roundup is curated included in weekly roundup
 

 return type: NSArray<SWGCurated>*
 */
-(NSNumber*) addCuratedWithCompletionBlock :(NSString*) appid 
     appkey:(NSString*) appkey 
     title:(NSString*) title 
     link:(NSString*) link 
     item_date:(NSString*) item_date 
     details:(NSString*) details 
     status:(NSString*) status 
     public_comment:(NSString*) public_comment 
     original_date:(NSString*) original_date 
     author:(NSString*) author 
     processed:(NSString*) processed 
     domain:(NSString*) domain 
     screenshot_url:(NSString*) screenshot_url 
     resolved_url:(NSString*) resolved_url 
     weekly_summary:(NSString*) weekly_summary 
     weekly_roundup:(NSString*) weekly_roundup 
    
    completionHandler: (void (^)(NSArray<SWGCurated>* output, NSError* error))completionBlock;
    


/**

 retrieve a curated item
 retrieve a curated item

 @param curated_id id for the curated id
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 

 return type: NSArray<SWGCurated>*
 */
-(NSNumber*) getCurated_1WithCompletionBlock :(NSString*) curated_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGCurated>* output, NSError* error))completionBlock;
    


/**

 updatea a curated item
 updatea a curated item

 @param curated_id id of the curated item
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param title title of the curated item
 @param link url for the curated item
 @param item_date date applied to the curated item
 @param details raw details of the curated item
 @param status status of the curated item
 @param public_comment public comment on the curated item
 @param original_date original date of the curated item
 @param author author of the curated item
 @param processed has the curated item been processed
 @param domain domain of the curated item
 @param screenshot_url screenshot url for the curated item
 @param resolved_url resolved url for the item
 @param weekly_summary is curated item included in weekly summary
 @param weekly_roundup is curated included in weekly roundup
 

 return type: NSArray<SWGCurated>*
 */
-(NSNumber*) updateCuratedWithCompletionBlock :(NSNumber*) curated_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     title:(NSString*) title 
     link:(NSString*) link 
     item_date:(NSString*) item_date 
     details:(NSString*) details 
     status:(NSString*) status 
     public_comment:(NSString*) public_comment 
     original_date:(NSString*) original_date 
     author:(NSString*) author 
     processed:(NSString*) processed 
     domain:(NSString*) domain 
     screenshot_url:(NSString*) screenshot_url 
     resolved_url:(NSString*) resolved_url 
     weekly_summary:(NSString*) weekly_summary 
     weekly_roundup:(NSString*) weekly_roundup 
    
    completionHandler: (void (^)(NSArray<SWGCurated>* output, NSError* error))completionBlock;
    


/**

 delete a curated item
 delete a curated item

 @param curated_id id for the curated item
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 

 return type: NSArray<SWGCurated>*
 */
-(NSNumber*) deleteCuratedWithCompletionBlock :(NSString*) curated_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGCurated>* output, NSError* error))completionBlock;
    



@end