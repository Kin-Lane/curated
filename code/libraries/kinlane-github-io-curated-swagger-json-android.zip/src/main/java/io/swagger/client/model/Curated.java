package io.swagger.client.model;


import com.wordnik.swagger.annotations.*;
import com.fasterxml.jackson.annotation.JsonProperty;


@ApiModel(description = "")
public class Curated  {
  
  private String title = null;
  private String link = null;
  private String itemDate = null;

  
  /**
   * title of the curated item
   **/
  @ApiModelProperty(value = "title of the curated item")
  @JsonProperty("title")
  public String getTitle() {
    return title;
  }
  public void setTitle(String title) {
    this.title = title;
  }

  
  /**
   * url for the curated item
   **/
  @ApiModelProperty(value = "url for the curated item")
  @JsonProperty("link")
  public String getLink() {
    return link;
  }
  public void setLink(String link) {
    this.link = link;
  }

  
  /**
   * date applied to the curated item
   **/
  @ApiModelProperty(value = "date applied to the curated item")
  @JsonProperty("item_date")
  public String getItemDate() {
    return itemDate;
  }
  public void setItemDate(String itemDate) {
    this.itemDate = itemDate;
  }

  

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Curated {\n");
    
    sb.append("  title: ").append(title).append("\n");
    sb.append("  link: ").append(link).append("\n");
    sb.append("  itemDate: ").append(itemDate).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}
