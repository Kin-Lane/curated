package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.ApiInvoker;

import io.swagger.client.model.*;

import java.util.*;

import io.swagger.client.model.Curated;

import org.apache.http.HttpEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;

import java.util.Map;
import java.util.HashMap;
import java.io.File;

public class CuratedApi {
  String basePath = "https://curated.api.kinlane.com/";
  ApiInvoker apiInvoker = ApiInvoker.getInstance();

  public void addHeader(String key, String value) {
    getInvoker().addDefaultHeader(key, value);
  }

  public ApiInvoker getInvoker() {
    return apiInvoker;
  }

  public void setBasePath(String basePath) {
    this.basePath = basePath;
  }

  public String getBasePath() {
    return basePath;
  }

  
  
  public List<Curated>  getCurated (String appid, String appkey, String query) throws ApiException {
    Object postBody = null;

    

    // create path and map variables
    String path = "/curated/".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    // header params
    Map<String, String> headerParams = new HashMap<String, String>();
    // form params
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (query != null)
      queryParams.put("query", ApiInvoker.parameterToString(query));
    

    

    String[] contentTypes = {
      
    };
    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if (contentType.startsWith("multipart/form-data")) {
      // file uploading
      MultipartEntityBuilder builder = MultipartEntityBuilder.create();
      

      HttpEntity httpEntity = builder.build();
      postBody = httpEntity;
    } else {
      // normal form params
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Curated>) ApiInvoker.deserialize(response, "array", Curated.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  
  public List<Curated>  addCurated (String appid, String appkey, String title, String link, String itemDate, String details, String status, String publicComment, String originalDate, String author, String processed, String domain, String screenshotUrl, String resolvedUrl, String weeklySummary, String weeklyRoundup) throws ApiException {
    Object postBody = null;

    

    // create path and map variables
    String path = "/curated/".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    // header params
    Map<String, String> headerParams = new HashMap<String, String>();
    // form params
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (title != null)
      queryParams.put("title", ApiInvoker.parameterToString(title));
    if (link != null)
      queryParams.put("link", ApiInvoker.parameterToString(link));
    if (itemDate != null)
      queryParams.put("item_date", ApiInvoker.parameterToString(itemDate));
    if (details != null)
      queryParams.put("details", ApiInvoker.parameterToString(details));
    if (status != null)
      queryParams.put("status", ApiInvoker.parameterToString(status));
    if (publicComment != null)
      queryParams.put("public_comment", ApiInvoker.parameterToString(publicComment));
    if (originalDate != null)
      queryParams.put("original_date", ApiInvoker.parameterToString(originalDate));
    if (author != null)
      queryParams.put("author", ApiInvoker.parameterToString(author));
    if (processed != null)
      queryParams.put("processed", ApiInvoker.parameterToString(processed));
    if (domain != null)
      queryParams.put("domain", ApiInvoker.parameterToString(domain));
    if (screenshotUrl != null)
      queryParams.put("screenshot_url", ApiInvoker.parameterToString(screenshotUrl));
    if (resolvedUrl != null)
      queryParams.put("resolved_url", ApiInvoker.parameterToString(resolvedUrl));
    if (weeklySummary != null)
      queryParams.put("weekly_summary", ApiInvoker.parameterToString(weeklySummary));
    if (weeklyRoundup != null)
      queryParams.put("weekly_roundup", ApiInvoker.parameterToString(weeklyRoundup));
    

    

    String[] contentTypes = {
      
    };
    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if (contentType.startsWith("multipart/form-data")) {
      // file uploading
      MultipartEntityBuilder builder = MultipartEntityBuilder.create();
      

      HttpEntity httpEntity = builder.build();
      postBody = httpEntity;
    } else {
      // normal form params
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Curated>) ApiInvoker.deserialize(response, "array", Curated.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  
  public List<Curated>  getCurated_1 (String curatedId, String appid, String appkey) throws ApiException {
    Object postBody = null;

    

    // create path and map variables
    String path = "/curated/{curated_id}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "curatedId" + "\\}", apiInvoker.escapeString(curatedId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    // header params
    Map<String, String> headerParams = new HashMap<String, String>();
    // form params
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    

    

    String[] contentTypes = {
      
    };
    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if (contentType.startsWith("multipart/form-data")) {
      // file uploading
      MultipartEntityBuilder builder = MultipartEntityBuilder.create();
      

      HttpEntity httpEntity = builder.build();
      postBody = httpEntity;
    } else {
      // normal form params
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Curated>) ApiInvoker.deserialize(response, "array", Curated.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  
  public List<Curated>  updateCurated (Integer curatedId, String appid, String appkey, String title, String link, String itemDate, String details, String status, String publicComment, String originalDate, String author, String processed, String domain, String screenshotUrl, String resolvedUrl, String weeklySummary, String weeklyRoundup) throws ApiException {
    Object postBody = null;

    

    // create path and map variables
    String path = "/curated/{curated_id}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "curatedId" + "\\}", apiInvoker.escapeString(curatedId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    // header params
    Map<String, String> headerParams = new HashMap<String, String>();
    // form params
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (title != null)
      queryParams.put("title", ApiInvoker.parameterToString(title));
    if (link != null)
      queryParams.put("link", ApiInvoker.parameterToString(link));
    if (itemDate != null)
      queryParams.put("item_date", ApiInvoker.parameterToString(itemDate));
    if (details != null)
      queryParams.put("details", ApiInvoker.parameterToString(details));
    if (status != null)
      queryParams.put("status", ApiInvoker.parameterToString(status));
    if (publicComment != null)
      queryParams.put("public_comment", ApiInvoker.parameterToString(publicComment));
    if (originalDate != null)
      queryParams.put("original_date", ApiInvoker.parameterToString(originalDate));
    if (author != null)
      queryParams.put("author", ApiInvoker.parameterToString(author));
    if (processed != null)
      queryParams.put("processed", ApiInvoker.parameterToString(processed));
    if (domain != null)
      queryParams.put("domain", ApiInvoker.parameterToString(domain));
    if (screenshotUrl != null)
      queryParams.put("screenshot_url", ApiInvoker.parameterToString(screenshotUrl));
    if (resolvedUrl != null)
      queryParams.put("resolved_url", ApiInvoker.parameterToString(resolvedUrl));
    if (weeklySummary != null)
      queryParams.put("weekly_summary", ApiInvoker.parameterToString(weeklySummary));
    if (weeklyRoundup != null)
      queryParams.put("weekly_roundup", ApiInvoker.parameterToString(weeklyRoundup));
    

    

    String[] contentTypes = {
      
    };
    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if (contentType.startsWith("multipart/form-data")) {
      // file uploading
      MultipartEntityBuilder builder = MultipartEntityBuilder.create();
      

      HttpEntity httpEntity = builder.build();
      postBody = httpEntity;
    } else {
      // normal form params
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "PUT", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Curated>) ApiInvoker.deserialize(response, "array", Curated.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  
  public List<Curated>  deleteCurated (String curatedId, String appid, String appkey) throws ApiException {
    Object postBody = null;

    

    // create path and map variables
    String path = "/curated/{curated_id}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "curatedId" + "\\}", apiInvoker.escapeString(curatedId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    // header params
    Map<String, String> headerParams = new HashMap<String, String>();
    // form params
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    

    

    String[] contentTypes = {
      
    };
    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if (contentType.startsWith("multipart/form-data")) {
      // file uploading
      MultipartEntityBuilder builder = MultipartEntityBuilder.create();
      

      HttpEntity httpEntity = builder.build();
      postBody = httpEntity;
    } else {
      // normal form params
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Curated>) ApiInvoker.deserialize(response, "array", Curated.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
}
