using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace io.swagger.Model {
  public class Note {
    

    /* type of note */
    
    public string Type { get; set; }

    

    /* text of note */
    
    public string Note { get; set; }

    

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Note {\n");
      
      sb.Append("  Type: ").Append(Type).Append("\n");
      
      sb.Append("  Note: ").Append(Note).Append("\n");
      
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  
  
}