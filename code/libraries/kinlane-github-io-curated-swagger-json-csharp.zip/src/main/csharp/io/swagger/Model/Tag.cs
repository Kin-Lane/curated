using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace io.swagger.Model {
  public class Tag {
    

    /* text tag */
    
    public string Tag { get; set; }

    

    /* number of items curated with tag */
    
    public int? CuratedCount { get; set; }

    

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Tag {\n");
      
      sb.Append("  Tag: ").Append(Tag).Append("\n");
      
      sb.Append("  CuratedCount: ").Append(CuratedCount).Append("\n");
      
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  
  
}