using System;
using System.Collections.Generic;
using io.swagger.client;
using io.swagger.Model;

namespace io.swagger.Api {
  
  public class CuratedApi {
    string basePath;
    private readonly ApiInvoker apiInvoker = ApiInvoker.GetInstance();

    public CuratedApi(String basePath = "https://curated.api.kinlane.com/")
    {
      this.basePath = basePath;
    }

    public ApiInvoker getInvoker() {
      return apiInvoker;
    }

    // Sets the endpoint base url for the services being accessed
    public void setBasePath(string basePath) {
      this.basePath = basePath;
    }

    // Gets the endpoint base url for the services being accessed
    public String getBasePath() {
      return basePath;
    }

    

    /// <summary>
    /// retrieves all curated items retrieves all curated items
    /// </summary>
    /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
     /// <param name="Query">a text query to search across curated items</param>
    
    /// <returns></returns>
    public List<curated>  GetCurated (string Appid, string Appkey, string Query) {
      // create path and map variables
      var path = "/curated/".Replace("{format}","json");

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      if (Query != null){
        queryParams.Add("query", apiInvoker.ParameterToString(Query));
      }
      

      

      

      try {
        if (typeof(List<curated>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<curated>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<curated>) ApiInvoker.deserialize(response, typeof(List<curated>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// add curated add curated
    /// </summary>
    /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
     /// <param name="Title">title of the curated item</param>
     /// <param name="Link">url for the curated item</param>
     /// <param name="ItemDate">date applied to the curated item</param>
     /// <param name="Details">raw details of the curated item</param>
     /// <param name="Status">status of the curated item</param>
     /// <param name="PublicComment">public comment on the curated item</param>
     /// <param name="OriginalDate">original date of the curated item</param>
     /// <param name="Author">author of the curated item</param>
     /// <param name="Processed">has the curated item been processed</param>
     /// <param name="Domain">domain of the curated item</param>
     /// <param name="ScreenshotUrl">screenshot url for the curated item</param>
     /// <param name="ResolvedUrl">resolved url for the item</param>
     /// <param name="WeeklySummary">is curated item included in weekly summary</param>
     /// <param name="WeeklyRoundup">is curated included in weekly roundup</param>
    
    /// <returns></returns>
    public List<curated>  AddCurated (string Appid, string Appkey, string Title, string Link, string ItemDate, string Details, string Status, string PublicComment, string OriginalDate, string Author, string Processed, string Domain, string ScreenshotUrl, string ResolvedUrl, string WeeklySummary, string WeeklyRoundup) {
      // create path and map variables
      var path = "/curated/".Replace("{format}","json");

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      if (Title != null){
        queryParams.Add("title", apiInvoker.ParameterToString(Title));
      }
      if (Link != null){
        queryParams.Add("link", apiInvoker.ParameterToString(Link));
      }
      if (ItemDate != null){
        queryParams.Add("item_date", apiInvoker.ParameterToString(ItemDate));
      }
      if (Details != null){
        queryParams.Add("details", apiInvoker.ParameterToString(Details));
      }
      if (Status != null){
        queryParams.Add("status", apiInvoker.ParameterToString(Status));
      }
      if (PublicComment != null){
        queryParams.Add("public_comment", apiInvoker.ParameterToString(PublicComment));
      }
      if (OriginalDate != null){
        queryParams.Add("original_date", apiInvoker.ParameterToString(OriginalDate));
      }
      if (Author != null){
        queryParams.Add("author", apiInvoker.ParameterToString(Author));
      }
      if (Processed != null){
        queryParams.Add("processed", apiInvoker.ParameterToString(Processed));
      }
      if (Domain != null){
        queryParams.Add("domain", apiInvoker.ParameterToString(Domain));
      }
      if (ScreenshotUrl != null){
        queryParams.Add("screenshot_url", apiInvoker.ParameterToString(ScreenshotUrl));
      }
      if (ResolvedUrl != null){
        queryParams.Add("resolved_url", apiInvoker.ParameterToString(ResolvedUrl));
      }
      if (WeeklySummary != null){
        queryParams.Add("weekly_summary", apiInvoker.ParameterToString(WeeklySummary));
      }
      if (WeeklyRoundup != null){
        queryParams.Add("weekly_roundup", apiInvoker.ParameterToString(WeeklyRoundup));
      }
      

      

      

      try {
        if (typeof(List<curated>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<curated>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<curated>) ApiInvoker.deserialize(response, typeof(List<curated>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// retrieve a curated item retrieve a curated item
    /// </summary>
    /// <param name="CuratedId">id for the curated id</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
    
    /// <returns></returns>
    public List<curated>  GetCurated_1 (string CuratedId, string Appid, string Appkey) {
      // create path and map variables
      var path = "/curated/{curated_id}".Replace("{format}","json").Replace("{" + "curated_id" + "}", apiInvoker.ParameterToString(CuratedId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<curated>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<curated>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<curated>) ApiInvoker.deserialize(response, typeof(List<curated>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// updatea a curated item updatea a curated item
    /// </summary>
    /// <param name="CuratedId">id of the curated item</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
     /// <param name="Title">title of the curated item</param>
     /// <param name="Link">url for the curated item</param>
     /// <param name="ItemDate">date applied to the curated item</param>
     /// <param name="Details">raw details of the curated item</param>
     /// <param name="Status">status of the curated item</param>
     /// <param name="PublicComment">public comment on the curated item</param>
     /// <param name="OriginalDate">original date of the curated item</param>
     /// <param name="Author">author of the curated item</param>
     /// <param name="Processed">has the curated item been processed</param>
     /// <param name="Domain">domain of the curated item</param>
     /// <param name="ScreenshotUrl">screenshot url for the curated item</param>
     /// <param name="ResolvedUrl">resolved url for the item</param>
     /// <param name="WeeklySummary">is curated item included in weekly summary</param>
     /// <param name="WeeklyRoundup">is curated included in weekly roundup</param>
    
    /// <returns></returns>
    public List<curated>  UpdateCurated (int? CuratedId, string Appid, string Appkey, string Title, string Link, string ItemDate, string Details, string Status, string PublicComment, string OriginalDate, string Author, string Processed, string Domain, string ScreenshotUrl, string ResolvedUrl, string WeeklySummary, string WeeklyRoundup) {
      // create path and map variables
      var path = "/curated/{curated_id}".Replace("{format}","json").Replace("{" + "curated_id" + "}", apiInvoker.ParameterToString(CuratedId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      if (Title != null){
        queryParams.Add("title", apiInvoker.ParameterToString(Title));
      }
      if (Link != null){
        queryParams.Add("link", apiInvoker.ParameterToString(Link));
      }
      if (ItemDate != null){
        queryParams.Add("item_date", apiInvoker.ParameterToString(ItemDate));
      }
      if (Details != null){
        queryParams.Add("details", apiInvoker.ParameterToString(Details));
      }
      if (Status != null){
        queryParams.Add("status", apiInvoker.ParameterToString(Status));
      }
      if (PublicComment != null){
        queryParams.Add("public_comment", apiInvoker.ParameterToString(PublicComment));
      }
      if (OriginalDate != null){
        queryParams.Add("original_date", apiInvoker.ParameterToString(OriginalDate));
      }
      if (Author != null){
        queryParams.Add("author", apiInvoker.ParameterToString(Author));
      }
      if (Processed != null){
        queryParams.Add("processed", apiInvoker.ParameterToString(Processed));
      }
      if (Domain != null){
        queryParams.Add("domain", apiInvoker.ParameterToString(Domain));
      }
      if (ScreenshotUrl != null){
        queryParams.Add("screenshot_url", apiInvoker.ParameterToString(ScreenshotUrl));
      }
      if (ResolvedUrl != null){
        queryParams.Add("resolved_url", apiInvoker.ParameterToString(ResolvedUrl));
      }
      if (WeeklySummary != null){
        queryParams.Add("weekly_summary", apiInvoker.ParameterToString(WeeklySummary));
      }
      if (WeeklyRoundup != null){
        queryParams.Add("weekly_roundup", apiInvoker.ParameterToString(WeeklyRoundup));
      }
      

      

      

      try {
        if (typeof(List<curated>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<curated>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "PUT", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<curated>) ApiInvoker.deserialize(response, typeof(List<curated>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// delete a curated item delete a curated item
    /// </summary>
    /// <param name="CuratedId">id for the curated item</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
    
    /// <returns></returns>
    public List<curated>  DeleteCurated (string CuratedId, string Appid, string Appkey) {
      // create path and map variables
      var path = "/curated/{curated_id}".Replace("{format}","json").Replace("{" + "curated_id" + "}", apiInvoker.ParameterToString(CuratedId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<curated>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<curated>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<curated>) ApiInvoker.deserialize(response, typeof(List<curated>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    
  }
  
}
