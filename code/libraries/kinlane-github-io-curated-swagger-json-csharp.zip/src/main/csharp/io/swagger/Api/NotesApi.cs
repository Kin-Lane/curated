using System;
using System.Collections.Generic;
using io.swagger.client;
using io.swagger.Model;

namespace io.swagger.Api {
  
  public class NotesApi {
    string basePath;
    private readonly ApiInvoker apiInvoker = ApiInvoker.GetInstance();

    public NotesApi(String basePath = "https://curated.api.kinlane.com/")
    {
      this.basePath = basePath;
    }

    public ApiInvoker getInvoker() {
      return apiInvoker;
    }

    // Sets the endpoint base url for the services being accessed
    public void setBasePath(string basePath) {
      this.basePath = basePath;
    }

    // Gets the endpoint base url for the services being accessed
    public String getBasePath() {
      return basePath;
    }

    

    /// <summary>
    /// get curated items notes get curated items notes
    /// </summary>
    /// <param name="CuratedId">id for the curated item</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
    
    /// <returns></returns>
    public List<note>  GetCuratedNotes (string CuratedId, string Appid, string Appkey) {
      // create path and map variables
      var path = "/curated/{curated_id}/notes/".Replace("{format}","json").Replace("{" + "curated_id" + "}", apiInvoker.ParameterToString(CuratedId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<note>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<note>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<note>) ApiInvoker.deserialize(response, typeof(List<note>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// add a curated note add a curated note
    /// </summary>
    /// <param name="CuratedId">id for the curated item</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
     /// <param name="Type">type of the note</param>
     /// <param name="Note">the full text of note</param>
    
    /// <returns></returns>
    public List<note>  AddCuratedNote (string CuratedId, string Appid, string Appkey, string Type, string Note) {
      // create path and map variables
      var path = "/curated/{curated_id}/notes/".Replace("{format}","json").Replace("{" + "curated_id" + "}", apiInvoker.ParameterToString(CuratedId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      if (Type != null){
        queryParams.Add("type", apiInvoker.ParameterToString(Type));
      }
      if (Note != null){
        queryParams.Add("note", apiInvoker.ParameterToString(Note));
      }
      

      

      

      try {
        if (typeof(List<note>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<note>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<note>) ApiInvoker.deserialize(response, typeof(List<note>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// delete a curated note delete a curated note
    /// </summary>
    /// <param name="CuratedId">id for the curated item</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
     /// <param name="NoteId">id for the note</param>
    
    /// <returns></returns>
    public List<note>  DeleteCuratedNote (string CuratedId, string Appid, string Appkey, string NoteId) {
      // create path and map variables
      var path = "/curated/{curated_id}/notes/{note_id}".Replace("{format}","json").Replace("{" + "curated_id" + "}", apiInvoker.ParameterToString(CuratedId)).Replace("{" + "note_id" + "}", apiInvoker.ParameterToString(NoteId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<note>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<note>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<note>) ApiInvoker.deserialize(response, typeof(List<note>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    
  }
  
}
