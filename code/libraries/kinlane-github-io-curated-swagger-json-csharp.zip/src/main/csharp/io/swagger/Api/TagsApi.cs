using System;
using System.Collections.Generic;
using io.swagger.client;
using io.swagger.Model;

namespace io.swagger.Api {
  
  public class TagsApi {
    string basePath;
    private readonly ApiInvoker apiInvoker = ApiInvoker.GetInstance();

    public TagsApi(String basePath = "https://curated.api.kinlane.com/")
    {
      this.basePath = basePath;
    }

    public ApiInvoker getInvoker() {
      return apiInvoker;
    }

    // Sets the endpoint base url for the services being accessed
    public void setBasePath(string basePath) {
      this.basePath = basePath;
    }

    // Gets the endpoint base url for the services being accessed
    public String getBasePath() {
      return basePath;
    }

    

    /// <summary>
    /// retrieves all tags for curated retrieves all tags for curated
    /// </summary>
    /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
     /// <param name="Query">a text query to search across curated items</param>
    
    /// <returns></returns>
    public List<curated>  GetCuratedTags (string Appid, string Appkey, string Query) {
      // create path and map variables
      var path = "/curated/tags/".Replace("{format}","json");

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      if (Query != null){
        queryParams.Add("query", apiInvoker.ParameterToString(Query));
      }
      

      

      

      try {
        if (typeof(List<curated>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<curated>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<curated>) ApiInvoker.deserialize(response, typeof(List<curated>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// curated tags by week curated tags by week
    /// </summary>
    /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
     /// <param name="Week">the week to retrieve tags by</param>
    
    /// <returns></returns>
    public List<curated>  GetCuratedTagsByWeek (string Appid, string Appkey, string Week) {
      // create path and map variables
      var path = "/curated/tags/byweek/".Replace("{format}","json");

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      if (Week != null){
        queryParams.Add("week", apiInvoker.ParameterToString(Week));
      }
      

      

      

      try {
        if (typeof(List<curated>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<curated>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<curated>) ApiInvoker.deserialize(response, typeof(List<curated>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// curated by tag and week curated by tag and week
    /// </summary>
    /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
     /// <param name="Tag">the tag to filter by</param>
     /// <param name="Week">the week to filter by, defaults to this week</param>
    
    /// <returns></returns>
    public List<curated>  GetCuratedTagCurated (string Appid, string Appkey, string Tag, string Week) {
      // create path and map variables
      var path = "/curated/tags/byweek/{tag}/curated/".Replace("{format}","json").Replace("{" + "tag" + "}", apiInvoker.ParameterToString(Tag));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      if (Week != null){
        queryParams.Add("week", apiInvoker.ParameterToString(Week));
      }
      

      

      

      try {
        if (typeof(List<curated>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<curated>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<curated>) ApiInvoker.deserialize(response, typeof(List<curated>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// delete curated tag delete curated tag
    /// </summary>
    /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
     /// <param name="Tag">Tag to be removed</param>
    
    /// <returns></returns>
    public List<curated>  DeleteCuratedTag (string Appid, string Appkey, string Tag) {
      // create path and map variables
      var path = "/curated/tags/{tag}".Replace("{format}","json").Replace("{" + "tag" + "}", apiInvoker.ParameterToString(Tag));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<curated>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<curated>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<curated>) ApiInvoker.deserialize(response, typeof(List<curated>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// get curated tags get curated tags
    /// </summary>
    /// <param name="CuratedId">id for curated item</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
    
    /// <returns></returns>
    public List<tag>  GetCuratedTags_1 (string CuratedId, string Appid, string Appkey) {
      // create path and map variables
      var path = "/curated/{curated_id}/tags/".Replace("{format}","json").Replace("{" + "curated_id" + "}", apiInvoker.ParameterToString(CuratedId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<tag>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<tag>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<tag>) ApiInvoker.deserialize(response, typeof(List<tag>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// add curated tag add curated tag
    /// </summary>
    /// <param name="CuratedId">id for curated item</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
     /// <param name="Tag">tag name</param>
    
    /// <returns></returns>
    public List<tag>  AddCuratedTag (string CuratedId, string Appid, string Appkey, string Tag) {
      // create path and map variables
      var path = "/curated/{curated_id}/tags/".Replace("{format}","json").Replace("{" + "curated_id" + "}", apiInvoker.ParameterToString(CuratedId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      if (Tag != null){
        queryParams.Add("tag", apiInvoker.ParameterToString(Tag));
      }
      

      

      

      try {
        if (typeof(List<tag>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<tag>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<tag>) ApiInvoker.deserialize(response, typeof(List<tag>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// delete a curated item delete a curated item
    /// </summary>
    /// <param name="CuratedId">id for the curated item</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
     /// <param name="Tag">tag to upate on the curated item</param>
    
    /// <returns></returns>
    public List<tag>  DeleteCurated (string CuratedId, string Appid, string Appkey, string Tag) {
      // create path and map variables
      var path = "/curated/{curated_id}/tags/{tag}".Replace("{format}","json").Replace("{" + "curated_id" + "}", apiInvoker.ParameterToString(CuratedId)).Replace("{" + "tag" + "}", apiInvoker.ParameterToString(Tag));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<tag>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<tag>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<tag>) ApiInvoker.deserialize(response, typeof(List<tag>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    
  }
  
}
