using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace io.swagger.Model {
  public class Curated {
    

    /* title of the curated item */
    
    public string Title { get; set; }

    

    /* url for the curated item */
    
    public string Link { get; set; }

    

    /* date applied to the curated item */
    
    public string ItemDate { get; set; }

    

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Curated {\n");
      
      sb.Append("  Title: ").Append(Title).Append("\n");
      
      sb.Append("  Link: ").Append(Link).Append("\n");
      
      sb.Append("  ItemDate: ").Append(ItemDate).Append("\n");
      
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  
  
}