package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.ApiInvoker;

import io.swagger.client.model.*;

import java.util.*;

import io.swagger.client.model.Curated;
import io.swagger.client.model.Tag;

import com.sun.jersey.multipart.FormDataMultiPart;
import com.sun.jersey.multipart.file.FileDataBodyPart;

import javax.ws.rs.core.MediaType;

import java.io.File;
import java.util.Map;
import java.util.HashMap;

public class TagsApi {
  String basePath = "https://curated.api.kinlane.com/";
  ApiInvoker apiInvoker = ApiInvoker.getInstance();

  public ApiInvoker getInvoker() {
    return apiInvoker;
  }

  public void setBasePath(String basePath) {
    this.basePath = basePath;
  }

  public String getBasePath() {
    return basePath;
  }

  
  /**
   * retrieves all tags for curated
   * retrieves all tags for curated
   * @param appid your appid for accessing the API
   * @param appkey your appkey for accessing the API
   * @param query a text query to search across curated items
   * @return List<Curated>
   */
  public List<Curated> getCuratedTags (String appid, String appkey, String query) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/curated/tags/".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (query != null)
      queryParams.put("query", ApiInvoker.parameterToString(query));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Curated>) ApiInvoker.deserialize(response, "array", Curated.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * curated tags by week
   * curated tags by week
   * @param appid your appid for accessing the API
   * @param appkey your appkey for accessing the API
   * @param week the week to retrieve tags by
   * @return List<Curated>
   */
  public List<Curated> getCuratedTagsByWeek (String appid, String appkey, String week) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/curated/tags/byweek/".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (week != null)
      queryParams.put("week", ApiInvoker.parameterToString(week));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Curated>) ApiInvoker.deserialize(response, "array", Curated.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * curated by tag and week
   * curated by tag and week
   * @param appid your appid for accessing the API
   * @param appkey your appkey for accessing the API
   * @param tag the tag to filter by
   * @param week the week to filter by, defaults to this week
   * @return List<Curated>
   */
  public List<Curated> getCuratedTagCurated (String appid, String appkey, String tag, String week) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/curated/tags/byweek/{tag}/curated/".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "tag" + "\\}", apiInvoker.escapeString(tag.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (week != null)
      queryParams.put("week", ApiInvoker.parameterToString(week));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Curated>) ApiInvoker.deserialize(response, "array", Curated.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * delete curated tag
   * delete curated tag
   * @param appid your appid for accessing the API
   * @param appkey your appkey for accessing the API
   * @param tag Tag to be removed
   * @return List<Curated>
   */
  public List<Curated> deleteCuratedTag (String appid, String appkey, String tag) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/curated/tags/{tag}".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "tag" + "\\}", apiInvoker.escapeString(tag.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Curated>) ApiInvoker.deserialize(response, "array", Curated.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * get curated tags
   * get curated tags
   * @param curatedId id for curated item
   * @param appid your appid for accessing the API
   * @param appkey your appkey for accessing the API
   * @return List<Tag>
   */
  public List<Tag> getCuratedTags_1 (String curatedId, String appid, String appkey) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/curated/{curated_id}/tags/".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "curatedId" + "\\}", apiInvoker.escapeString(curatedId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Tag>) ApiInvoker.deserialize(response, "array", Tag.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * add curated tag
   * add curated tag
   * @param curatedId id for curated item
   * @param appid your appid for accessing the API
   * @param appkey your appkey for accessing the API
   * @param tag tag name
   * @return List<Tag>
   */
  public List<Tag> addCuratedTag (String curatedId, String appid, String appkey, String tag) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/curated/{curated_id}/tags/".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "curatedId" + "\\}", apiInvoker.escapeString(curatedId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (tag != null)
      queryParams.put("tag", ApiInvoker.parameterToString(tag));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Tag>) ApiInvoker.deserialize(response, "array", Tag.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * delete a curated item
   * delete a curated item
   * @param curatedId id for the curated item
   * @param appid your appid for accessing the API
   * @param appkey your appkey for accessing the API
   * @param tag tag to upate on the curated item
   * @return List<Tag>
   */
  public List<Tag> deleteCurated (String curatedId, String appid, String appkey, String tag) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/curated/{curated_id}/tags/{tag}".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "curatedId" + "\\}", apiInvoker.escapeString(curatedId.toString()))
      .replaceAll("\\{" + "tag" + "\\}", apiInvoker.escapeString(tag.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Tag>) ApiInvoker.deserialize(response, "array", Tag.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
}
