package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.ApiInvoker;

import io.swagger.client.model.*;

import java.util.*;

import io.swagger.client.model.Curated;

import com.sun.jersey.multipart.FormDataMultiPart;
import com.sun.jersey.multipart.file.FileDataBodyPart;

import javax.ws.rs.core.MediaType;

import java.io.File;
import java.util.Map;
import java.util.HashMap;

public class CuratedByWeekApi {
  String basePath = "https://curated.api.kinlane.com/";
  ApiInvoker apiInvoker = ApiInvoker.getInstance();

  public ApiInvoker getInvoker() {
    return apiInvoker;
  }

  public void setBasePath(String basePath) {
    this.basePath = basePath;
  }

  public String getBasePath() {
    return basePath;
  }

  
  /**
   * curated items by week
   * curated items by week
   * @param appid your appid for accessing the API
   * @param appkey your appkey for accessing the API
   * @param week the week number
   * @return List<Curated>
   */
  public List<Curated> getCuratedByWeek (String appid, String appkey, Integer week) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/curated/byweek/".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (week != null)
      queryParams.put("week", ApiInvoker.parameterToString(week));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Curated>) ApiInvoker.deserialize(response, "array", Curated.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * curated items by week archived
   * curated items by week archived
   * @param appid your appid for accessing the API
   * @param appkey your appkey for accessing the API
   * @param week the week number
   * @return List<Curated>
   */
  public List<Curated> getCuratedByWeekPublished (String appid, String appkey, Integer week) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/curated/byweek/archive/".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (week != null)
      queryParams.put("week", ApiInvoker.parameterToString(week));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Curated>) ApiInvoker.deserialize(response, "array", Curated.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * curated items by week published
   * curated items by week published
   * @param appid your appid for accessing the API
   * @param appkey your appkey for accessing the API
   * @param week the week number
   * @return List<Curated>
   */
  public List<Curated> getCuratedByWeekPublished_1 (String appid, String appkey, Integer week) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/curated/byweek/published/".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (week != null)
      queryParams.put("week", ApiInvoker.parameterToString(week));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Curated>) ApiInvoker.deserialize(response, "array", Curated.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * curated item by week for review
   * curated item by week for review
   * @param appid your appid for accessing the API
   * @param appkey your appkey for accessing the API
   * @param week the week number
   * @return List<Curated>
   */
  public List<Curated> getCuratedByWeekReview (String appid, String appkey, Integer week) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/curated/byweek/review/".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (week != null)
      queryParams.put("week", ApiInvoker.parameterToString(week));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Curated>) ApiInvoker.deserialize(response, "array", Curated.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
}
